# TapTapCard — GitHub Pages

## كيف تستعمله؟

الرابط العام يكون بهذا الشكل:

`https://USERNAME.github.io/REPOSITORY/?id=demo`

ولزبون جديد، انسخ `profiles/demo.json` إلى ملف جديد مثل:

`profiles/syly.json`

ثم عدّل:
- `name` اسم الشخص أو المحل
- `bio` وصف قصير
- `profileImage` صورة البروفايل
- `coverImage` صورة الغلاف
- `links` روابط Instagram / Facebook / TikTok
- `phone` رقم الهاتف
- `whatsapp` رقم واتساب بصيغة دولية بدون `+` أو مسافات
- `theme.bg1` و `theme.bg2` لونَي الخلفية

بعد رفع التعديلات إلى GitHub يصبح رابط الزبون:

`https://USERNAME.github.io/REPOSITORY/?id=syly`

## الصور

ضع صور الزبون داخل `assets/` ثم استعمل المسار، مثلاً:

`assets/syly-profile.jpg`

و:

`assets/syly-cover.jpg`

ثم اكتب المسار في ملف JSON.

## ملاحظة

هذا الإصدار Static بالكامل، لذلك لا يحتاج قاعدة بيانات أو استضافة مدفوعة. كل زبون له ملف JSON ورابط خاص.
